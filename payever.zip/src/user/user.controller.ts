import {
  Body,
  Controller,
  Post,
  Get,
  Delete,
  Put,
  Param,
  HttpStatus,
  HttpException,
  Inject,
} from '@nestjs/common';
import { UserService } from './user.service';
import { ImageService } from './image.service';
import { User } from './schemas/user.schema';
import axios, { AxiosResponse } from 'axios';

@Controller('api/users')
export class UserController {
  constructor(
    private readonly userService: UserService,
    @Inject(ImageService) private readonly imageService: ImageService,
  ) {}

  @Get()
  async findAll(): Promise<User[]> {
    return this.userService.findAll();
  }

  @Get(':id')
  async get(@Param('id') id: string): Promise<User> {
    try {
      const response: AxiosResponse<{ data: User }> = await axios.get(
        `https://reqres.in/api/users/${id}`,
      );
      return response.data.data;
    } catch (error) {
      throw new HttpException('User not found', HttpStatus.NOT_FOUND);
    }
  }

  @Get(':id/avatar')
  async getAvatar(@Param('id') id: string): Promise<string> {
    console.log(id);
    const user = this.userService.findOne(id);
    const image = this.imageService.getImage(id);
    if (!image) {
      const response = await axios.get((await user).avatar);

      // Get the image buffer from the response
      const imageBuffer = await axios
        .get(response.data.data.avatar, {
          responseType: 'arraybuffer',
        })
        .then((response) => response.data);

      // Save the image buffer and hash to the database
      const image = this.imageService.storeImage(id, imageBuffer);
      (await image).save();

      // Return the base64-encoded representation of the image buffer
      return imageBuffer.toString('base64');
    }

    return image;
  }

  @Post()
  async create(@Body() user: User): Promise<User> {
    return this.userService.create(user);
  }

  @Delete(':id')
  async delete(@Param('id') id): Promise<User> {
    return this.userService.delete(id);
  }

  @Put(':id')
  async update(@Body() user: User, @Param('id') id): Promise<User> {
    return this.userService.update(id, user);
  }
}
