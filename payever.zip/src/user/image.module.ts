import { Module } from '@nestjs/common';
import { ImageService } from './image.service';
import { ImageSchema } from './schemas/image.schema';
import { MongooseModule } from '@nestjs/mongoose';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Image', schema: ImageSchema }]),
  ],
  controllers: [],
  providers: [ImageService],
  exports: [ImageService],
})
export class ImageModule {}
