/* eslint-disable prettier/prettier */
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectConnection, InjectModel } from '@nestjs/mongoose';
import { Connection, Model } from 'mongoose';
import { GridFSBucket } from 'mongodb';
import { Image } from './schemas/image.schema';
import { createHash } from 'crypto';

@Injectable()
export class ImageService {
  private bucket: GridFSBucket;

  constructor(
    @InjectModel(Image.name) private readonly imageModel: Model<Image>,
    @InjectConnection() private readonly connection: Connection,
  ) {
    this.bucket = new GridFSBucket(connection.db, {
      bucketName: 'images',
    });
  }

  async storeImage(userId: string, imageBuffer: Buffer): Promise<Image> {
    const hash = createHash('sha256').update(imageBuffer).digest('hex');

    const existingImage = await this.imageModel.findOne({ userId, hash });
    if (existingImage) {
      return existingImage;
    }

    const data = `${userId}-${hash}.png`;

    const uploadStream = this.bucket.openUploadStream(data);
    uploadStream.end(imageBuffer);

    const image = new this.imageModel({ userId, hash, data });
    await image.save();

    return image;
  }

  async getImage(
    userId: string,
  ): Promise<string> {
    const image = await this.imageModel.findOne({ userId });
    if (!image) {
      throw new NotFoundException('Image not found');
    }

    return image.data.toString('base64');
  }

  async delete(userId: string): Promise<Image>
  {
    const image = this.imageModel.findByIdAndRemove(userId);
    return image;
  }
}
