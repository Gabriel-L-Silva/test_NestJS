export default {
  mongoURI:
    'mongodb+srv://glsfacom:JGjTTwh9zc0NIIEj@cluster0.dcrylim.mongodb.net/?retryWrites=true&w=majority',
};
