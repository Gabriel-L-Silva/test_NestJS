export default {
  mongoURI:
    'mongodb+srv://glsfacom:w0asKKtadSyfH5ce@cluster0.dcrylim.mongodb.net/?retryWrites=true&w=majority',
  RABBIT_MQ_URI: 'amqp://localhost:5672',
  RABBIT_MQ_USERS_EXCHANGE: 'users_created',
  RABBIT_MQ_USERS_QUEUE: 'users',
  RMQ_EXCHANGE: 'messages',
  EMAIL: 'your_email@gmail.com',
  EMAIL_PASSWORD: 'your_password',
  NAME: 'your Name',
};
