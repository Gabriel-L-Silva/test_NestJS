const stub = {
  someMethod: jest.fn(),
  someAttribute: true,
};

module.exports = () => stub;
