import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserSchema } from './user/schemas/user.schema';
import { UserController } from './user/user.controller';
import { UserService } from './user/user.service';
import config from './config/keys';
import { ImageService } from './user/image.service';
import { ImageModule } from './user/image.module';

@Module({
  imports: [
    MongooseModule.forRoot(config.mongoURI),
    MongooseModule.forFeature([{ name: 'User', schema: UserSchema }]),
    ImageModule,
  ],
  controllers: [AppController, UserController],
  providers: [AppService, UserService, ImageService],
})
export class AppModule {}
