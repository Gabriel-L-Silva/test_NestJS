I had some trouble with modules, so i could not complete the task.
I'am sending the task anyway because I think it shows my value as a developer and express how much I could contribute to the company with the right guidance.

Thank you for the opportunity.