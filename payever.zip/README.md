# Dependencies
NodeJS 18.15.11+

TypeScript 3.4+

NestJS Framework

MongoDB 4.4+

RabbitMQ 3.7+

## How to run
1. Open 'src/config/services.ts' insert your data.
2. Run '$ npm install'.
3. Run '$ npm run start'.
4. Send Postman requests.